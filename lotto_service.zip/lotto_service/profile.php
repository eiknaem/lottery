<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>ข้อมูลส่วนตัว</title>
</head>
<body class="body">
    <table class="table">
        <thead>
          <tr>
            <th class="th"><a href="index.php" class="a">หน้าแรก</a></th>
            <th class="th"><a href="input_lotto.php" class="a">กรอกรางวัล</a></th>
            <th class="th"><a href="lucky_lotto.php" class="a">ตรวจรางวัลแบบถูกรางวัล</a></th>
            <th class="th"><a href="unlucky_lotto.php" class="a">ตรวจรางวัลแบบไม่ถูกรางวัล</a></th>
            <th class="th"><a href="profile.php" class="a">ข้อมูลส่วนตัว</a></th>
          </tr>
        </thead>
    </table> 
        <div>
            <p>
                <img src="picture/PICTURE.jpg" class="pic" alt="picture">
                <h2 class="data">ข้อมูล</h2>
                <p class="n1">เมธวิน อุกฤษฏ์อัสดร (มีน)</p>
                <p class="n1">รหัสนศ: 1630903555 </p>
                <p class="n1">วิชา: CE223 เซต:236A</p>
                <h2 class="personal">ประวัติส่วนตัว</h2>
                <p class="n1">ศึกษาที่: ม.กรุงเทพ , คณะวิศวกรรมศาสตร์ , สาขาวิชาวิศวกรรมคอมพิวเตอร์และหุ่นยนต์</p>
                <p class="n1">วันเกิด: 22 มีนาคม 2544 อายุ 21 ปี</p>
                <div style="text-align: center">
                    <h1>Credit</h1>
                    <a href="https://weichie.com/blog/curl-api-calls-with-php/%22%3ECurl">Call API with PHP</a>
                    <a href="https://stackoverflow.com/questions/13851528/how-to-pop-an-alert-message-box-using-php%22%3EHow">How to alert in PHP</a>
                </div>
            </p>
        </div>
</body>
</html>