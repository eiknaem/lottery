<!DOCTYPE html>
<?php
  if(isset($_POST['SubmitButton']) && !empty($_POST['text_plain'])){
    $number = $_POST['text_plain'];
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, "http://localhost:5000/".$number);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $result = json_decode(curl_exec($curl));
 
    curl_close($curl);
    if(count($result)===0){
      echo "<script type='text/javascript'>alert('คุณไม่ถูกรางวัลประจำงวดนี้!');</script>";
    }else{
        $day  = $result[0]->Day;
        $month = $result[0]->Month;
        $reward = $result[0]->Reward;
        echo "<script type='text/javascript'>alert('คุณถูก $reward ประจำวันที่ $day เดือน $month');</script>";
    }
  }
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>กรอกรางวัล</title>
</head>
<body class="body">
    <table class="table">
        <thead>
          <tr>
            <th class="th"><a href="index.php" class="a">หน้าแรก</a></th>
            <th class="th"><a href="input_lotto.php" class="a">กรอกรางวัล</a></th>
            <th class="th"><a href="lucky_lotto.php" class="a">ตรวจรางวัลแบบถูกรางวัล</a></th>
            <th class="th"><a href="unlucky_lotto.php" class="a">ตรวจรางวัลแบบไม่ถูกรางวัล</a></th>
            <th class="th"><a href="profile.php" class="a">ข้อมูลส่วนตัว</a></th>
          </tr>
        </thead> 
    </table>
    <br>
    <form method="post" action="" class="n2">กรอกเลขรางวัล: 
    <input type="text" name="text_plain" maxlength="6" onKeyUp="if(isNaN(this.value)){ alert('กรุณากรอกตัวเลข'); this.value='';}"/>
    <input type="submit" name="SubmitButton" value="ยืนยัน" >
</body>
</html>