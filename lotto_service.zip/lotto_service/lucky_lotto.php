<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>ตรวจรางวัลแบบถูกรางวัล</title>
</head>
<body class="body">
    <table class="table">
        <thead>
          <tr>
            <th class="th"><a href="index.php" class="a">หน้าแรก</a></th>
            <th class="th"><a href="input_lotto.php" class="a">กรอกรางวัล</a></th>
            <th class="th"><a href="lucky_lotto.php" class="a">ตรวจรางวัลแบบถูกรางวัล</a></th>
            <th class="th"><a href="unlucky_lotto.php" class="a">ตรวจรางวัลแบบไม่ถูกรางวัล</a></th>
            <th class="th"><a href="profile.php" class="a">ข้อมูลส่วนตัว</a></th>
          </tr>
        </thead> 
    </table>
</body>
</html>